package com.example.haohanzhang.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.jupiter.calculator.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    Button btn_1s, btn_1min, btn_10min, btn_1h, btn_clear, btn_send;
    EditText et_input;
    int second, minute, hour;


    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_1s = findViewById(R.id.btn_1s);
        btn_1min = findViewById(R.id.btn_1min);
        btn_10min = findViewById(R.id.btn_10min);
        btn_1h = findViewById(R.id.btn_1h);
        btn_clear = findViewById(R.id.btn_clear);
        btn_send = findViewById(R.id.btn_send);
        et_input = findViewById(R.id.et_input);

        btn_1s.setOnClickListener(this);
        btn_1min.setOnClickListener(this);
        btn_10min.setOnClickListener(this);
        btn_1h.setOnClickListener(this);
        btn_send.setOnClickListener(this);
        btn_send.setOnClickListener(this);

    }


    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btn_1s:
                add1s();
                et_input.setVisibility(View.VISIBLE);
                break;
            case R.id.btn_1min:
                add1min();
                et_input.setVisibility(View.VISIBLE);
                break;
            case R.id.btn_10min:
                add10min();
                et_input.setVisibility(View.VISIBLE);
                break;
            case R.id.btn_1h:
                add1h();
                et_input.setVisibility(View.VISIBLE);
                break;
            case R.id.btn_clear:
                clear();
                et_input.setVisibility(View.VISIBLE);
                break;
            case R.id.btn_send:
                sendMessage();
                break;
        }
    }


    private void sendMessage()
    {

    }

    private String getResult()
    {
        if(this.second >= 60)
        {
            this.minute += this.second/60;
            this.second -= 60;
        }
        if(this.minute >= 60)
        {
            this.hour += this.minute/60;
            this.minute -= 60;
        }
        return(this.hour+" hour "+this.minute+" minute "+this.second+" second");
    }

    private void add1s()
    {
        this.second += 1;
        String output = getResult();
        et_input.setText(output);
    }

    private void add1min()
    {
        this.minute += 1;
        String output = getResult();
        et_input.setText(output);
    }

    private void add10min()
    {
        this.minute += 10;
        String output = getResult();
        et_input.setText(output);
    }

    private void add1h()
    {
        this.hour += 1;
        String output = getResult();
        et_input.setText(output);
    }

    private void clear()
    {
        this.second = 0;
        this.minute = 0;
        this.hour = 0;
        et_input.setText(" ");
    }


}

