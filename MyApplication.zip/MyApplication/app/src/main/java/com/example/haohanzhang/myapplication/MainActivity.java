package com.example.haohanzhang.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.jupiter.calculator.R;

public class MainActivity extends AppCompatActivity
{
    Button btn_1s, btn_1min, btn_10min, btn_1h, btn_clear, btn_send;
    EditText et_input;
    int second, minute, hour;


    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_1s = findViewById(R.id.btn_1s);
        btn_1min = findViewById(R.id.btn_1min);
        btn_10min = findViewById(R.id.btn_10min);
        btn_1h = findViewById(R.id.btn_1h);
       // btn_clear = (Button) findViewById(R.id.btn_clear);
        btn_send = findViewById(R.id.btn_send);
        et_input = findViewById(R.id.et_input);
        btn_1s.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            //Write your logic in this section, do the same for all your other buttons.
            }
        });
        btn_1min.setOnClickListener(this);
        btn_10min.setOnClickListener(this);
        btn_1h.setOnClickListener(this);
        btn_clear.setOnClickListener(this);
        btn_send.setOnClickListener(this);
    }


    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.btn_1s:
                add1s();
            case R.id.btn_1min:
                add1min();
            case R.id.btn_10min:
                add10min();
            case R.id.btn_1h:
                add1h();
            //case R.id.btn_clear:
                //et_input.setText(" ");
            case R.id.btn_send:
                sendMessage();
                break;
        }
    }


    private void sendMessage()
    {

    }

    private String getResult()
    {
        if(second == 60)
        {
            second = 0;
            minute += 1;
        }
        if(minute == 60)
        {
            minute = 0;
            hour += 1;
        }
        return(hour+"hour"+minute+"minute"+second+"second");
    }

    private void add1s()
    {
        second += 1;
        String output = getResult();
        et_input.setText(output);
    }

    private void add1min()
    {
        minute += 1;
        String output = getResult();
        et_input.setText(output);
    }

    private void add10min()
    {
        minute += 10;
        String output = getResult();
        et_input.setText(output);
    }

    private void add1h()
    {
        hour += 1;
        String output = getResult();
        et_input.setText(output);
    }

}

